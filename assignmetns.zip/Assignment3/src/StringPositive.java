
public class StringPositive {
	String str;
	public StringPositive(String str)
	{
		this.str=str;
	}
	String result="Positive String";
	public String driver()
	{
		for(int i=0;i<str.length()-1;i++)
		{
			if(str.charAt(i)<str.charAt(i+1))
			{
				continue;
			}
			else
			{
				result="-ve String";
				break;
			}
		}
		return result;
	}
}
