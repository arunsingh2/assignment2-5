public class OperationsInString {
	public static void main(String args[])
	{
		StrngOprtn obj=new StrngOprtn();
		System.out.println("added String:"+obj.add("abhishek"));
		System.out.println("Hashed String:"+obj.repHash("abhishek"));
		System.out.println("remove duplicasy from String:"+obj.remDup("abhishek"));
		System.out.println("odd Upper case converted String:"+obj.oddUppercase("abhishek"));
		StringPositive sp=new StringPositive("Abhishek");
		System.out.println(sp.driver());
		DateD d2=new DateD(24,07,1997);
		DateD d1=new DateD(1,2,2019);
		String res=DateDemo.getDifference(d1, d2);
		System.out.println(res);
	}

}
