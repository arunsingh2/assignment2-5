
public class DateD  
    { 
        int d, m, y; 
  
        public DateD(int d, int m, int y) 
        { 
            this.d = d; 
            this.m = m; 
            this.y = y; 
        } 
  
    } 