public class DateDemo {
	static String getDifference(DateD dt1,DateD dt2) 
    { 
		int yy=dt1.y-dt2.y;
		int mm;
		int dd=(dt1.m*dt1.d)-(dt2.m*dt2.d);
		if(dd<0)
		{
			dd=dd+365;
			mm=dd/30;
			if(mm!=0)
			dd=dd%mm;
		}
		else
		{
			mm=dd/30;
			System.out.println("dd"+dd);
			System.out.println("mm"+mm);
			if(mm!=0)
			dd=dd%mm;
		}
		return dd+"/"+mm+"/"+yy;
    } 
}
