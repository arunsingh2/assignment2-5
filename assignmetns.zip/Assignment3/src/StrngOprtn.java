
public class StrngOprtn
{
	public String add(String s1)
	{
		return s1+""+s1;
	}
	public String repHash(String s)
	{
		String str="";
		for(int i=1;i<=s.length();i++)
		{
			if(i%2==1)
			{
				str=str+"#";
			}
			else
			{
				str=str+s.substring(i-1, i);
			}
		}
		return str;
	}
	public String remDup(String s)
	{
		String str="";
		for(int i=0;i<s.length();i++)
		{
			str=str+s.substring(i,i+1);
			for(int j=0;j<s.length();j++)
			{
				if(i==j)
				{
					continue;
				}
				else
				{
					if(s.charAt(i)==s.charAt(j))
					{
						continue;
					}
					else
					{
						str=str+s.substring(j,j+1);
					}
				}
			}
			s=str;
			str="";
		}
		return s;
	}

	public String oddUppercase(String s)
	{
		String str="";
		for(int i=1;i<=s.length();i++)
		{
			if(i%2==1)
			{
				str=str+Character.toString(Character.toUpperCase(s.charAt(i-1)));
			}
			else
			{
				str=str+s.substring(i-1, i);
			}
		}
		return str;
	} 
}