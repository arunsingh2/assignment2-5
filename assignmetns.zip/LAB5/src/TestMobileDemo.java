
public class TestMobileDemo {
	public static void main(String args[])
	{
		Mobile1 m1=new Mobile1();
		Mobile2 m2=new Mobile2();
		System.out.println(m1.camera());
		System.out.println(m1.flash());
		System.out.println("***************************");
		System.out.println(m2.camera());
		System.out.println(m2.flash());
	}
}
