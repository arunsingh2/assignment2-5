package com.cg.eis.service;

public interface EmpService {
	public String getInsSchm(double sal,String desgn);
}
