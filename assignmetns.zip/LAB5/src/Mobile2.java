
public class Mobile2 implements MobileFeatures
{
	@Override
	public String camera() {
		return "20 MegaPixel";
	}

	@Override
	public String flash() {
		return "LED Flash";
	}
}