
public abstract class Account
{
	long accountNum;
	double accountBal;
	Person accHolder;
	static int count=1;
	public Account(){}

	public long getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(long accountNum) {
		this.accountNum = accountNum;
	}

	public double getAccountBal() {
		return accountBal;
	}

	public void setAccountBal(double accountBal) {
		this.accountBal = accountBal;
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}

	public void deposite(double money)
	{
		accountBal=accountBal+money;
	}
	public abstract void withdraw(double money);
	/*{
		if((accountBal=accountBal-money)<500)
		{
			return;
		}
		accountBal=accountBal-money;
	} */
	public double getBalance()
	{
		return accountBal;
	}
}
