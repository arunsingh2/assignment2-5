
public class Current extends Account{
	 double overDftLim;
	public double getOverDftLim()
	{
		return overDftLim;
	}
	public void setOverDftLim(double overDftLim)
	{
		this.overDftLim=overDftLim;
	}
	public void withdraw(double amount)
	{
		boolean status;
		status = checkOvDft(amount);
		
		if(status==true)
		{
			accountBal=accountBal-amount;
			System.out.println("Txn Successfull,balance:"+accountBal);
		}
	}
	
	public boolean checkOvDft(double amount)
	{
		boolean status;
		if(amount>overDftLim)
		{
			status=false;
			System.out.println("No Sufficient funds");
		}
		else if(accountBal - amount< overDftLim)
		{
			System.out.println("Unsuccessfull txn");
			status=false;
		}
		else
		{
			accountBal=accountBal-amount;
			System.out.println("txn successfull,balance:"+accountBal);
			status=true;
		}
		return status;
	}
}
