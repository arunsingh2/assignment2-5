
public enum GenderEmployee {
MALE,FEMALE,Wrong_Input;
}
