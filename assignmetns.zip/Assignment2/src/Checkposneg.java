
public class Checkposneg {
	public static void main(String args[])
	{
		if(Integer.parseInt(args[0])<0)
		{
			System.out.println("number is -ve");
		}
		else
			System.out.println("number is +ve");
	}
}
